# Spicetify Dark

## Screenshots

Window:

![Spicetify Dark](https://i.imgur.com/Dpfy5Gz.png)

Full desktop:

![Full desktop](https://i.redd.it/ephz750tqld31.png)

## Info

I'm not sure who the original creator of this theme was. It is featured as a screenshot on the [spicetify-cli repository](https://github.com/khanhas/spicetify-cli) but isn't linked anywhere. It's essentially a dark version of the default spicetify-cli theme.

Featured in [this rice](https://www.reddit.com/r/unixporn/comments/ck6rqj/i3plasma_my_first_rice_lil_purpp/), of which the dotfiles can be found [here](https://github.com/SlimShadyIAm/dotfiles).
