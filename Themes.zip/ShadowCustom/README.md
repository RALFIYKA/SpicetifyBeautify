# ShadowCustom

## Screenshots

![Night](./7JL4785.png)

## More

Highly inspired by SpicetifyDefault & Dark.
Comment suggestions and bugs below, thanks.
