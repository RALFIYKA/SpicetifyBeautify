# Night Owl

## Screenshots

![Night Owl](./screenshot.png)

## More

Highly inspired by [Night](https://github.com/morpheusthewhite/spicetify-themes/tree/master/Night) & [VSCode - Night Owl](https://marketplace.visualstudio.com/items?itemName=sdras.night-owl).
