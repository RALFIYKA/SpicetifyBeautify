# MoonChild

## Screenshots

![MoonChild](./moonchild1.jpg)
![MoonChild](./moonchild2.jpg)

## More

Required font:
- Karla

## Credits

Theme developed by [bonecharm](https://www.reddit.com/user/bonecharm)

Based on Thicktify theme created by [8roly](https://sta.sh/01uc5a80m46u)
