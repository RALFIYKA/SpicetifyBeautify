# Kaapi
## Screenshots

### Base
![](home.png)

### Gruvbox
![](https://user-images.githubusercontent.com/1497894/81452747-ecf03880-9187-11ea-9303-56bddd477247.png)

