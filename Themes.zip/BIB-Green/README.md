# BIB and Green

## Screenshots

![BIB and Green](https://i.imgur.com/35nNpVh.png)
![BIB and Green Playlist](https://i.imgur.com/lCNuXEW.png)

## More

Designed to match [BIB 2.0](https://www.deviantart.com/niivu/art/BIB-2-0-800970529) Windows 10 theme
Feel free to comment if there's any weird colors anywhere. I think I got most of them. (: