**Theme Discontinued...**
## Versions

**v 0.9 beta**

-   [x] half baked release!!
-   [x] don't mind the "few" icon mismatches :D.

**v 0.5 beta**

-   [x] Changed all possible icons.
-   [x] Fixed the color mismatch.
-   [x] A few optimizations.

**v 0.2 beta**

-   [x] Fixed the two bars shown in now playing  
-   [x] An attempt to fix the logo not showing issue for platforms other than macos.  
-   [x] A few optimizations.

**v 0.1 beta**

-   [x] Added the Spotify logo.  
-   [x] Fixed the friend activity bar.  
-   [x] Fixed text colors inside album and playlist.  
-   [x] Fixed overlapping of sidebar items.  
-   [x] A few optimizations.

* * *
