# WintergatanBlueprint

## Screenshots

![WintergatanBlueprint](https://github.com/DoubleJarvis/SpicetifyThemes/raw/master/images/SpicetifyWintergatanBlueprint.png)

## More

Source: https://github.com/DoubleJarvis/SpicetifyThemes