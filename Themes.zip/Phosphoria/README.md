# Phosphoria

## Screenshots

![Phosphoria](./screenshot1.png)

## More

A twist on the original Spotify dark theme; Phosphoria provides a more modern aesthetic and a glowing green phosphorus vibe.   


 - Required Font: [Oswald](https://fonts.google.com/specimen/Oswald) (with Oswald Light)

## Credits: 

Developed and designed by [RadArcadeKid](https://github.com/RadArcadeKid), based on the the [Black](https://github.com/morpheusthewhite/spicetify-themes/tree/master/Black) and [Lovelace](https://github.com/morpheusthewhite/spicetify-themes/tree/master/Lovelace) themes. 

