# OneDarkish

## Screenshots

![screenshot of OneDarkish applied to an artist's page](https://github.com/lukeiamyo/spicetify-themes/blob/master/OneDarkish/screenshot_artist.png)
![screenshot of OneDarkish applied to a playlist](https://github.com/lukeiamyo/spicetify-themes/blob/master/OneDarkish/screenshot_playlist.png)

## More

Inspired by [One Dark UI](https://atom.io/themes/one-dark-ui). Feedback is always appreciated :).
