# Spicy

## Screenshots

![Spicy](./screenshot.png)

## More

(This theme was previously posted on a [spectrum chat](https://spectrum.chat/spicetify/themes?tab=posts))

Credits to [@Altirix](https://github.com/Altirix)
