# Elementary

## Screenshots

### Base

![Base](https://i.imgur.com/w8A5q9U.png)

### BlueContrast

![BlueContrast](./screenshot.jpg)

### Nightcity
![Nightcity](./nightcity.png)


## More

(This theme was previously posted on a [spectrum chat](https://spectrum.chat/spicetify/themes?tab=posts))

Credits to [@theredhood13](https://github.com/theredhood13)

BlueContrast/Nightcity by [AmitGujar](https://github.com/AmitGujar)
