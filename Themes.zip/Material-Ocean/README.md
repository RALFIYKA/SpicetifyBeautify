# Material-Ocean

## Screenshot

![screnshot](./screnshot.png)

## Info

Font: [JetBrains Mono](https://www.jetbrains.com/lp/mono)

Part of material ocean themes, [checkout here](https://github.com/material-ocean) for the same theme for different apps
