# Black

## Screenshots

![Base](https://i.imgur.com/HjK3Gab.png)

![Purple](purple.png)

## Info

Inspired by [Dark](https://github.com/morpheusthewhite/spicetify-themes/tree/master/Dark)
