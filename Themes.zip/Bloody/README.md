# Bloody

## Screenshots

![MacOS Spotify #1](screenshot1.jpg)
![MacOS Spotify #2](screenshot2.jpg)

## More

Modification of SpicetifyDark, but with black and red instead of blue and green
