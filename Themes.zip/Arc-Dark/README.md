# Arc-Dark

## Screenshots

![Arc-Dark](screenshot.png)

## Credits
Theme developed by [meliot](https://github.com/meliot/Arc-Dark-Spotify-Theme)

## Arc Theme
Highly inspired by [arc-theme](https://github.com/horst3180/arc-theme)
