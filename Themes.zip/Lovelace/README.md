# Lovelace

## Screenshots

### Base

![Artist](./artist-screenshot.png)

![Playlist](./playlist-screenshot.png)

### Mint

![Artist](artist-screenshot-mint.png)

![Playlist](./playlist-screenshot-mint.png)

## More

Author: [adriankarlen](https://github.com/adriankarlen)

Based on [this](https://raw.githubusercontent.com/mbadolato/iTerm2-Color-Schemes/master/schemes/lovelace.itermcolors) iTerm2 color scheme. 

Also used [TychoAwake](https://github.com/morpheusthewhite/spicetify-themes/tree/master/TychoAwake) as base for the theme.
