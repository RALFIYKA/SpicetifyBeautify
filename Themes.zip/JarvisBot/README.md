# JarvisBot

## Screenshots

![JarvisBot](https://github.com/DoubleJarvis/SpicetifyThemes/raw/master/images/SpicetifyJarvisBot.png)

## More

Source: https://github.com/DoubleJarvis/SpicetifyThemes