# Gruvbox-Gold

## Screenshots

![Gruvbox-Gold](screenshot.png)

## More
* Feel free to change the gold (FABD2F in color.ini) to a different accent color

## Credits

Theme created by Greyowl

## Gruvbox

Inspired by [gurvbox](https://github.com/morhetz/gruvbox)

