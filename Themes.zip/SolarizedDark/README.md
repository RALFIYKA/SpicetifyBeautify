# Solarized Dark

## Screenshots

![Solarized-Dark](screenshot.png)

## Credits
Original colorscheme by [Ethan Schnoover](https://ethanschoonover.com/solarized)

