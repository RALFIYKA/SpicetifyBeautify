# Bittersweet

## Screenshots

![Home screen](https://i.imgur.com/0XBojv8.jpg)
![Album view](https://i.imgur.com/NLiIYGb.png)

## Credits

[bandithedoge](https://github.com/bandithedoge) - this theme

[EliverLara](https://github.com/EliverLara) - original Sweet color scheme

## More

Another theme based on [Sweet](https://github.com/EliverLara/Sweet) by [EliverLara](https://github.com/EliverLara). This one is basically Sweet that looks more like Sweet.
