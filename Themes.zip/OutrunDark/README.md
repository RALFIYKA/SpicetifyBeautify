# OutrunDark

## Screenshots

![OutrunDark](./OutrunDark.png)
![OutrunDark](./OutrunDark_overview.png)

## Credits
Based on [the Outrun Theme for VSCode](https://marketplace.visualstudio.com/items?itemName=samrapdev.outrun). Credits to @Solano695
