# Aritim-Dark

## Screenshots

![Aritim-Dark](screenshot.png)

## Credits
Theme developed by [kaluk1321](https://github.com/kaluk1321)

## Aritim-Dark
Highly inspired by [Aritim-Dark](https://github.com/Mrcuve0/Aritim-Dark)
