# Arc-Green

## Screenshots

![Arc-Green](screenshot.png)

## Credits
Theme developed by [Nick Schneider](https://github.com/CampAsAChamp/Arc-Green-Spotify-Theme)

## Arc Theme
Highly inspired by [arc-theme](https://github.com/horst3180/arc-theme) but with a little green accent to better match Spotify's original design

### Removing scrollbar
To remove the scrollbar open **user.css** and remove both slashes and * from each line in the webkit-scrollbar selector