# Flatten

## Screenshots

![Flatten](flatten.png)

## More
This theme is based on original Spotify theme.
Feel free to report broken UI.

## Credits

Theme created by qwersteve07
