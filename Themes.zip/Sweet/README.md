# Sweet

## Screenshots

Window: 

![Sweet](/Sweet/screenshot.png?raw=true)

## More

Based on the [Sweet](https://github.com/EliverLara/hyper-sweet) color scheme.
