# Honne 

## Screenshot 

![](https://raw.githubusercontent.com/twoswordsman/spicetify-themes/master/HONNE/honneimg.png)

## More

Based on the Music Artist Honne ◑by HamLord
