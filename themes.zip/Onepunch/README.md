# Onepunch

## Screenshots

![1](./1.png)
![2](./2.png)

## More

#### Details

A project intended to redesign the Spotify app.As you know Saitama is only a "hero for fun", this is going to take a while even though he can finish an enemy with just one punch. I hope you'll like it! Suggestions will always help me to make it look better. So, feel free to drop your feedback.

#### Changelogs

**I am not going to work on this anymore. If anyone wants to continue it or remake it, feel free to do it. Thank you.**

Wondering what is changed, then check this [file](./changelog.md).

#### Contact

Click **[here](https://twitter.com/_okarin_001)** for _feedback_, _sharing new ideas_ and _reporting bugs_ only.  
Format for bug reporting:  

     Operating System(!important):

     Description of issue:
