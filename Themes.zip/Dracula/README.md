# Dracula

## Screenshots

![Browse](https://i.imgur.com/MAjsCVm.png)
![Album](https://i.imgur.com/z7thIss.png)
![Playlist](https://i.imgur.com/OXm7N6y.png)

## More (note for Windows and Linux users)

The font "Helvetica Neue" is used by default, which isn't available on typical Windows and Linux machines. It will be replaced by Arial on Windows machines, and sans-serif on Linux machines. If you don't like this, replace "Helvetica Neue" with the font of your choice in the `user.css` file. After making any changes, run `spicetify apply`.
