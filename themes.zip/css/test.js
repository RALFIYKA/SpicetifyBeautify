//XOX.
//OXO.
//XOX.
alert("!!! FUCK YOU ACTIVEXOBJECT !!!")
//OXO.
//XOX.
//OXO.