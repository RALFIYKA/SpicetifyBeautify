# Blueballs

## Screenshots

![blueballs](screenshot.png)

## More

Theme based on the [blueballs](https://github.com/bandithedoge/blueballs) color scheme.
