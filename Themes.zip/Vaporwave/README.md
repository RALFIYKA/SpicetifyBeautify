# Vaporwave

## Screenshots

#### NewRetro (Default)

![Arc-Dark](./NewRetro.PNG)

#### SeaPunk

![Arc-Dark](./SeaPunk.PNG)

## How to install

To switch between the color themes run

```
spicetify config color_scheme <scheme name>
```

## Credits

Theme developed by [LivingWithHippos](https://github.com/LivingWithHippos/spicetify-themes)

Highly inspired by [vapoRwave](https://github.com/moldach/vapoRwave)
