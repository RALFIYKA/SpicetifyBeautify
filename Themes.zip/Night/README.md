# Night

## Screenshots

![Night](./screenshot.png)

## More

Highly inspired by SpicetifyDefault.