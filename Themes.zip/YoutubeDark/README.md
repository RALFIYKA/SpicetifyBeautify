# YoutubeDark

## Screenshots

![youtube dark](ytdark.png)

## More
Based on the YouTube dark theme.
https://ec965.github.io/
