# CherryBlossom
Dark minimal theme based on a Cherry Blossom Wallpaper. 
![Wallpaper](wallpaper.jpg)
Enjoy!

## Screenshots

### CherryBlossom

![Home Page Screenshot](screenshot.png)
![Playlist Screenshot](screenshot1.png)

### Coral

![Home Page Screenshot](screenshotCoral.png)
![Playlist Screenshot](screenshot1Coral.png)

## More
Theme developed by [@toby-wong](github.com/toby-wong)

If someone can figure out the following issues please let me know :)
- corner radius when hovering to edit playlist image
- downloaded status is fully colored
- connect to device shadow
