# Gradianto

## Screenshots

![Alt text](./Screenshots/Screenshot_1.png "Screenshot 1")
![Alt text](./Screenshots/Screenshot_2.png "Screenshot 2")
![Alt text](./Screenshots/Screenshot_3.png "Screenshot 3")

## More

Please let me know if there's any problem with the theme! :) Hope you enjoy.
