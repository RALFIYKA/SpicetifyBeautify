# Pop-Dark

## Screenshots

![Screenshot 1](./screenshot1.jpg)
![Screenshot 2](./screenshot2.jpg)

## Info

Designed to match the new PoP_OS! dark mode.
