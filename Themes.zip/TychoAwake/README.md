# TychoAwake

## Screenshots

![TychoAwake](https://github.com/DoubleJarvis/SpicetifyThemes/raw/master/images/SpicetifyTychoAwake.png)

## More

Source: https://github.com/DoubleJarvis/SpicetifyThemes